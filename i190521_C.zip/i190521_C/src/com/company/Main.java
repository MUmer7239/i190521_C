package com.company;
import javax.lang.model.element.Name;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.util.Objects;
import java.util.Scanner;
import java.lang.String;
import java.awt.TextField;
import java.util.logging.SocketHandler;

//Customer Class
class Customer
{
    protected
    String name,Address,Acc_Number,P_no;
    double Acc_Balance;

    Customer()
    {
        name = null;
        Address = null;
        Acc_Number = null;
        P_no = null;
        Acc_Balance = 0.0;

    }

    Customer(String n, String Add, String Acc_n, String P_n, double Acc_B)
    {
        name = n;
        Address = Add;
        Acc_Number = Acc_n;
        P_no = P_n;
        Acc_Balance = Acc_B;


    }

}

class Account extends Customer
{
    protected
    char Account_Type,Transaction_date, Transaction_time;
    double Remaining_Balance,D_Balnc;
    Scanner s = new Scanner(System.in);

    /*Account()
    {
        Account_Type = '\0';
    }*/
    /*Account(char AT)
    {
        Account_Type = AT;
    }*/

    void checkBalance()
    {
        System.out.println("Your Name is : " + name);
        System.out.println("Your Account Balance is : " + Acc_Balance);
    }

    void printStatement()
    {
        System.out.println("Your complete detail is : ");
        System.out.println("    Name : " + name);
        System.out.println("    Account Number : " + Acc_Number);
        System.out.println("    Phone Number : " + P_no);
        System.out.println("    Address : " + Address);
        System.out.println("    Transaction Date : " /* + date*/ );
        System.out.println("    Transaction Time : " /* + time*/ );
        System.out.println("    Remaining Balance is : "/* + reamining balance*/);

    }

    void makeDeposit()
    {
        System.out.print("Please, enter amount to deposit :");
        D_Balnc = s.nextDouble();
    }

    void TransferAmount()
    {
        System.out.print("Enter your account number:");

    }
}

class SavingAccount extends Account
{

}

class CheckingAccount extends Account
{

}

public class Main {

    public static void main(String[] args) {
        // write your code her

        String choice;
        String Pno, Ano;
        double NBL;
        String new_name,new_Phone_number,new_address;
        int check=0;
        String  Account_Type;




        String []Name;
        Name = new String[]{"M Umer", "M Ali", "Asher Farhan", "Akbar Ali", "Ali Ahmad", "M Farooq", " Ali Raza", "Shamim Ahmad", "Umer Farooq",
                "Ahmad Raza","","","","",""};
        String []Phone_Number;
        Phone_Number = new String[]{"03129812341","03019834232","03119312149","03452217341","03109212611","03009811341","03319816343",
                "03009812342","03219812314","03059812746","","","","",""};
        String []Account_Number;
        Account_Number = new String[]{"213456","113455","213454","713457","212436","613476","257456","113451","113451","226452","","","","",""};
        String Address[];
        Address = new String[]{"Street#1, House#1, ISB","Street#2, House#2, ISB","Steret#3, House#3, ISB","Street#4 House#4, ISB","Street#5, House#5, ISB",
                "Street#6, House#6, ISB", "Street#7, House#7, ISB","Street#8 House#8, ISB","Street#9, House#9, ISB","Strret#10, House#10, ISB","",",","",""};
        double Balance[];
        Balance = new double[]{12500,35980,447890,72319,87456,13200,67345,98670,34190,87239,0,0,0,0,0};






        System.out.println("\t\t\t\t\t\tWelcome To Account Management System\n");
        System.out.println("\t\t\t\t\t------------------------------");
        System.out.print(" Do you Already Have an Account or You want to Make a New Account?\n Press A for Already & N for New Account: ");
        Scanner sc = new Scanner(System.in);
        choice = sc.nextLine();
        System.out.print(" Do you want to create a Saving  Account or a Checking Account? \n Press S/s for Saving & C/c for Checking: ");
        Account_Type = sc.nextLine();

        System.out.println("------------------------------\n");


        //IN CASE OF NEW ACCOUNT
        int a=10;

        if (Objects.equals(choice, "N") || Objects.equals(choice, "n") && Objects.equals(Account_Type, "N") || Objects.equals(Account_Type, "n"))
        {
            System.out.print(" Enter Your Name:");
            new_name = sc.nextLine();
            Name[a] = new_name;

            System.out.print(" Enter Your Phone Number:");
            new_Phone_number = sc.next();
            Phone_Number[a] = new_Phone_number;

            System.out.print(" Enter Your Address:");
            new_address = sc.next();
            Address[a] = new_address;

            System.out.print(" Enter Account Number of your choice:");
            Ano = sc.next();
            Account_Number[a] = Ano;

            System.out.print("\n\n Enter a 7-digit Pin Code of your choice for the New Account:");
            Pno = sc.next();
            Phone_Number[a] = Pno;

            System.out.print(" Enter the Balance for your new account.It is mandatory to enter:");
            NBL = sc.nextDouble();
            Balance[a] = NBL;

            a++;

            Customer New_Customer = new Customer(new_name,new_address,Ano,Pno,NBL);
        }

        char ch;

        System.out.println("Congrats! You account has been created.");
        System.out.println("Choose which operation you want to do.\n Enter the number:");

        System.out.println(" 1. Login To Account.");
        System.out.println(" 2. Close the Account.");
        System.out.println(" 3. Exit.");
        ch = sc.next().charAt(0);

        char ch1;
        switch(ch)
        {
            case 1:
                System.out.println("Login Successful!");
                System.out.println("Choose which operation you want to do.\n Enter the number:");

                System.out.println(" 1. Cash Deposit.");
                System.out.println(" 2. Cash Withdrawal.");
                System.out.println(" 3. Exit");
                System.out.println(" 4. Display All Details(of Account & Owner.");
                ch1 = sc.next().charAt(0);

                break;

            case 2:
                System.out.println("Account Closed\n\n");
                System.out.flush();




        }

       /* else if(Objects.equals(choice, "Y") || Objects.equals(choice, "Y"))
        {
            while(check==0)
            {
                System.out.print("\n\n Enter Pin Code of your Account:");
                Pno = sc.next();

                System.out.println(" Enter Account Number of your Account:");
                Ano = sc.next();
*/
    }
}

